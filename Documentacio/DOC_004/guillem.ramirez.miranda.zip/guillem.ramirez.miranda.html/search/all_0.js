var searchData=
[
  ['a_5fbuit',['a_buit',['../class_arbre.html#aa74ec0d2b601487b822eb70100330582',1,'Arbre']]],
  ['afegir_5findividu',['afegir_individu',['../classpoblacio.html#a4b276498dce7806435f5da6c0bb1b497',1,'poblacio']]],
  ['arbre',['Arbre',['../class_arbre.html',1,'Arbre&lt; T &gt;'],['../class_arbre.html#a3f613426983169266297eb841996845e',1,'Arbre::Arbre()'],['../class_arbre.html#a8f8615c19988334f9b77dc51f44acc6d',1,'Arbre::Arbre(const Arbre &amp;original)']]],
  ['arbre_2ehh',['Arbre.hh',['../_arbre_8hh.html',1,'']]],
  ['arrel',['arrel',['../class_arbre.html#a5bb0de70185e3d8b65a6489cb38b8bc6',1,'Arbre']]]
];
