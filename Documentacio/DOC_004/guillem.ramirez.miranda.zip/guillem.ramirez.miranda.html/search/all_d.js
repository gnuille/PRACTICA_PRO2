var searchData=
[
  ['trobar',['trobar',['../classpoblacio.html#a6534584e7b9b47c8e1f5f800851daef7',1,'poblacio']]]
];
