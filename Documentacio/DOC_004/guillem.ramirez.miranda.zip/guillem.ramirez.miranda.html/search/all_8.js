var searchData=
[
  ['normal',['normal',['../classmatrerial__genetic.html#a7dd3b921332743dbe09f8212695cfc04',1,'matrerial_genetic']]]
];
