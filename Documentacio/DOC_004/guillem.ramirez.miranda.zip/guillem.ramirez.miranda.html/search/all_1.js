var searchData=
[
  ['c1',['c1',['../classparell__cromosomes.html#af9f8dd9154e1c23176a9b4fc99876d2c',1,'parell_cromosomes']]],
  ['c2',['c2',['../classparell__cromosomes.html#aeef1645e5ce4276c9b33efefb0fde5fa',1,'parell_cromosomes']]],
  ['completar_5farbre',['completar_arbre',['../classindividu.html#a26629996515393200f023f0f13141e6a',1,'individu']]],
  ['consultar_5fnom',['consultar_nom',['../classindividu.html#a524053921304f914deac29c6baa80e15',1,'individu']]],
  ['consultar_5fsexe',['consultar_sexe',['../classindividu.html#a30ab21dfd66b20a748bcf41e0b3108a0',1,'individu']]],
  ['cromosoma',['cromosoma',['../classcromosoma.html',1,'cromosoma'],['../classcromosoma.html#ada7b15cea1a9368f7c66a36365988eee',1,'cromosoma::cromosoma()']]],
  ['cromosoma_2ehh',['cromosoma.hh',['../cromosoma_8hh.html',1,'']]]
];
