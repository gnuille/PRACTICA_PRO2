var searchData=
[
  ['individu',['individu',['../classindividu.html#af1ba9dc86a04bff6b41ed2d1cf3202b9',1,'individu::individu()'],['../classindividu.html#a6c431979119a07f4dc2be041d6cf73da',1,'individu::individu(setiterator pare, setiterator mare, string nfill)']]]
];
