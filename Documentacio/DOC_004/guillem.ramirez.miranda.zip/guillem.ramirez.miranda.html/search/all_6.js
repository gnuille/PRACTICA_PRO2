var searchData=
[
  ['llegir',['llegir',['../classindividu.html#a309eb865a39352302fd8d97cf67584bb',1,'individu::llegir()'],['../classespecie.html#af1a08ff40fdb79abb1d78c06b8131306',1,'especie::llegir()'],['../classmatrerial__genetic.html#aa0935cfcdc01fcaf44e90b16661423a0',1,'matrerial_genetic::llegir()'],['../classcromosoma.html#aea40ee7333c4da3f472d095ce6a69623',1,'cromosoma::llegir()'],['../classpoblacio.html#a0fbbb44255553f61cf18af398ad92061',1,'poblacio::llegir()']]]
];
