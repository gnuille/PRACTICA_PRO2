var searchData=
[
  ['cromosoma',['cromosoma',['../classcromosoma.html',1,'']]]
];
