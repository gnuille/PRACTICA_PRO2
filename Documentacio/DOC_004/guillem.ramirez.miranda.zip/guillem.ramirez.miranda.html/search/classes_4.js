var searchData=
[
  ['matrerial_5fgenetic',['matrerial_genetic',['../classmatrerial__genetic.html',1,'']]]
];
