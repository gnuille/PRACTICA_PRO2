var searchData=
[
  ['getl',['getl',['../classespecie.html#ac09e154b4eae25155af3bdc98c2a18c3',1,'especie']]],
  ['getl0',['getl0',['../classespecie.html#a5ea723fe64398cd46cbc6e044b114fff',1,'especie']]],
  ['getlx',['getlx',['../classespecie.html#a98735feb10fd44e1316708566790ca95',1,'especie']]],
  ['getly',['getly',['../classespecie.html#aeae1b17938e4527858ad4d3f5949d182',1,'especie']]],
  ['getn',['getN',['../classespecie.html#a16cbac301660254cf39ef7f51690e507',1,'especie']]]
];
