var searchData=
[
  ['parell_5fcromosomes',['parell_cromosomes',['../classparell__cromosomes.html',1,'']]],
  ['poblacio',['poblacio',['../classpoblacio.html',1,'']]]
];
