var searchData=
[
  ['individu',['individu',['../classindividu.html',1,'']]]
];
