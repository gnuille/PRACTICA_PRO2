var indexSectionsWithContent =
{
  0: "acefgilmnoprst~",
  1: "aceimp",
  2: "aceimp",
  3: "acefgilmnoprst~",
  4: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Definicions de Tipus"
};

