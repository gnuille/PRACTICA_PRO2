var searchData=
[
  ['pare',['pare',['../classindividu.html#a6f379a03c06d9c39c47b20fa4b1a899b',1,'individu']]],
  ['parell_5fcromosomes',['parell_cromosomes',['../classparell__cromosomes.html',1,'parell_cromosomes'],['../classparell__cromosomes.html#a9d86452d029f65ccf80c8861c4914698',1,'parell_cromosomes::parell_cromosomes()'],['../classparell__cromosomes.html#ac03872e98719667206d6b9f6e002f2df',1,'parell_cromosomes::parell_cromosomes(const cromosoma &amp;c1, const cromosoma &amp;c2)']]],
  ['parell_5fcromosomes_2ehh',['parell_cromosomes.hh',['../parell__cromosomes_8hh.html',1,'']]],
  ['plantar',['plantar',['../class_arbre.html#a806d45f6f1d3a9dd357563979186f721',1,'Arbre']]],
  ['poblacio',['poblacio',['../classpoblacio.html',1,'poblacio'],['../classpoblacio.html#a8d6ad7ce285dd47c9cfd806e302d7086',1,'poblacio::poblacio()']]],
  ['poblacio_2ehh',['poblacio.hh',['../poblacio_8hh.html',1,'']]]
];
