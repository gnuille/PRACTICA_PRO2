var searchData=
[
  ['parell_5fcromosomes_2ehh',['parell_cromosomes.hh',['../parell__cromosomes_8hh.html',1,'']]],
  ['poblacio_2ehh',['poblacio.hh',['../poblacio_8hh.html',1,'']]]
];
