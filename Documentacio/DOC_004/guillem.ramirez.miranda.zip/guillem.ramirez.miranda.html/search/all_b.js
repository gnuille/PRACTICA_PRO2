var searchData=
[
  ['reproduir',['reproduir',['../classparell__cromosomes.html#a70760dca0beb7da1d59f70d8cfca83a5',1,'parell_cromosomes']]]
];
